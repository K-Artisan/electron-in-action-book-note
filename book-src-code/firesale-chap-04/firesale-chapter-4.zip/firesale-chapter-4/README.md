# Fire Sale

Completed code from [Electron in Action](http://bit.ly/electronjs).

- [Code from the end of Chapter 3](https://github.com/electron-in-action/firesale/tree/chapter-3)
- [Code from the end of Chapter 4](https://github.com/electron-in-action/firesale/tree/chapter-4)
- [Code from the end of Chapter 5](https://github.com/electron-in-action/firesale/tree/chapter-5)
- [Code from the end of Chapter 6](https://github.com/electron-in-action/firesale/tree/chapter-6)
- [Code from the end of Chapter 7](https://github.com/electron-in-action/firesale/tree/chapter-7)
- [Code from the end of Chapter 8](https://github.com/electron-in-action/firesale/tree/chapter-8)
- [Code from the starting point of Chapter 14](https://github.com/electron-in-action/firesale/tree/chapter-14-beginning)
- [Code from the end of Chapter 14](https://github.com/electron-in-action/firesale/tree/chapter-14-ending)
- [Code from the starting point of Chapter 15](https://github.com/electron-in-action/firesale/tree/chapter-15-beginning)
- [Code from the end of Chapter 15](https://github.com/electron-in-action/firesale/tree/chapter-15-ending)
- [Code from the end of Chapter 16](https://github.com/electron-in-action/firesale/tree/chapter-16-ending)